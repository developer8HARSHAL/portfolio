const myFunc = document.getElementsByTagName("h1");

for (let i = 0; i < myFunc.length; i++) {
  myFunc[i].textContent = "harshal";
}

